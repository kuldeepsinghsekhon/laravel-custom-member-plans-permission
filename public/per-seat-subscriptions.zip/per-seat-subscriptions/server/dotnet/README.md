# Subscriptions with per seat pricing

## Requirements
- [.NET Core]https://dotnet.microsoft.com/download)
- [Configured .env file](../../../README.md#env-config)


## How to run

1. Run the application
```
dotnet run
```

2. Go to `https://localhost:4242` or `http://localhost:42424` in your browser to see the demo
