# Subscriptions with per seat pricing

A [Go](https://golang.org) implementation

## Requirements

- Go
- [Configured .env file](../../../README.md#env-config)


## How to run

1. Run the application

```
go run server.go
```
